module jfxcounter {
	exports gui;

	requires javafx.base;
	requires javafx.controls;
	requires transitive javafx.graphics;
}