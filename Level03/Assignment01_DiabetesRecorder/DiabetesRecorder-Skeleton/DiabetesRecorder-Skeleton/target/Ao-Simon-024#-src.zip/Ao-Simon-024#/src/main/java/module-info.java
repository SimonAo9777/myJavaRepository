open module diabetesrecorder {

	requires java.sql;
	requires java.desktop;
	requires javafx.web;
	requires javafx.base;
	requires transitive javafx.graphics;
	requires transitive javafx.controls;
	requires jdk.jdi;
	requires jdk.compiler;



	
	
	
}