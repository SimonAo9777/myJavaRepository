package jdbc;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.SQLException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;

/**
 * CST_8288_21F Assignment 1 JUnit 5 Test
 * 
 * @author Simon Ao 040983402
 * @version July 4,2021
 * @References: Professor's tutorials
 * 
 */

class JDBCModelTest {

	private static String URL = "jdbc:mysql://localhost:3306/diabetesrecord?useUnicode=true&serverTimezone=UTC";
	private static String USER = "cst8288";
	private static String PASS = "8288";

	private JDBCModel model = new JDBCModel();
	Connection Connection = null;

	@BeforeEach
	void setUp() throws SQLException {
		model.setCredentials(USER, PASS);
		model.connectTo(URL);
		assertTrue(model.isConnected());

	}

	@AfterEach
	void tearDown() throws SQLException {
		model.close();
	}

	/**
	 * 
	 * Test valid URL
	 */

	@Test
	void testIsConnected() throws SQLException {
		model.setCredentials(USER, PASS);
		model.connectTo(URL);
		assertTrue(model.isConnected());
		model.close();
		assertFalse(model.isConnected());

		model.setCredentials("user", PASS);

		assertFalse(model.isConnected());

	}

	/**
	 * 
	 * Test login parameters
	 */
	@Test
	void testLoginWithMethod() throws SQLException {
		assertTrue(model.isConnected());
		String name = "John";
		String pass = "pass";
		assertEquals(2, model.loginWith(name, pass));
	}

	/**
	 * Test GetEntryTypes
	 */
	@Test
	void testGetEntryTypes() throws SQLException {
		List<String> li = null;
		assertTrue(model.isConnected());
		li = model.getEntryTypes();
		assertTrue(li.get(0).equalsIgnoreCase("After Meal"));
		assertTrue(li.get(1).equalsIgnoreCase("Bedtime"));
		assertTrue(li.get(2).equalsIgnoreCase("Before Meal"));
		assertTrue(li.get(3).equalsIgnoreCase("Fasting"));
		assertTrue(li.get(4).equalsIgnoreCase("Other"));
	}

	/**
	 * Test GetColumnNames
	 */
	@Test
	void testGetColumnNames() throws SQLException {
		List<String> li;
		assertTrue(model.isConnected());
		li = model.getColumnNames();
		assertTrue(li.contains("Id"));
		assertTrue(li.contains("EntryType"));
		assertTrue(li.contains("GlucoseValue"));
		assertTrue(li.contains("TakenAt"));
	}

	/**
	 * Test GetColumnNames
	 */

	@Test
	public void testGetAllGlucoseNumbersAndAddGlucoseValue() throws SQLException {
		assertTrue(model.isConnected());
		List<List<Object>> before = model.getAllGlucoseNumbers(2);
		model.addGlucoseValue("Other", 2, 12.0);
		List<List<Object>> after = model.getAllGlucoseNumbers(2);
		assertEquals(1, after.size() - before.size());

	}

	/**
	 * Test Close connection
	 */
	@Test
	void testClose() {
		assertTrue(model.isConnected());
		model.close();
		assertFalse(model.isConnected());
	}

}
